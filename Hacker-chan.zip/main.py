'''
Author : Zeke Redgrave(Alias)
Date Created:  June 10, 2019
Warning : This is App is not use for Commerial. Please don't own this App!
'''

import sys
import os
import area

area.Area().MenuArea()